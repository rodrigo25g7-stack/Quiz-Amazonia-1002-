const $ = id => document.getElementById(id);
const sections = ["welcome","quiz","evaluation","result","operator"];
let name = "", current = 0, answers = [], questions = [];

function show(id) { sections.forEach(s => $(s).classList.toggle("hidden", s !== id)); window.scrollTo({top:0,behavior:"smooth"}); }
async function api(url, options={}) {
  const response = await fetch(url, {credentials:"same-origin", headers:{"Content-Type":"application/json", ...(options.headers||{})}, ...options});
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.error || "Não foi possível concluir a operação.");
  return data;
}
async function registerVisit() { try { await api("/api/visit",{method:"POST",body:"{}"}); } catch {} }
function renderQuestion() {
  const q = questions[current];
  $("questionCount").textContent = `PERGUNTA ${current+1} DE ${questions.length}`;
  $("progressLabel").textContent = `${Math.round((current+1)/questions.length*100)}%`;
  $("progressBar").style.width = `${(current+1)/questions.length*100}%`;
  $("questionText").textContent = q.text;
  $("options").innerHTML = "";
  $("nextBtn").disabled = answers[current] === undefined;
  q.options.forEach((option,i) => {
    const button = document.createElement("button");
    button.type = "button"; button.className = "option" + (answers[current]===i ? " selected":"");
    const letter = document.createElement("span"); letter.className="letter"; letter.textContent=String.fromCharCode(65+i);
    const text = document.createElement("span"); text.textContent=option;
    button.append(letter,text);
    button.addEventListener("click",()=>{answers[current]=i;renderQuestion();});
    $("options").append(button);
  });
  $("nextBtn").textContent = current === questions.length-1 ? "Continuar →" : "Próxima pergunta →";
}
$("startBtn").addEventListener("click", async()=>{
  $("welcomeError").textContent="";
  name=$("participantName").value.trim().replace(/\s+/g," ");
  if(name.length<2){$("welcomeError").textContent="Digite seu nome para começar.";return;}
  try { const data=await api("/api/questions"); questions=data.questions; current=0;answers=[];renderQuestion();show("quiz"); }
  catch(e){$("welcomeError").textContent=e.message;}
});
$("nextBtn").addEventListener("click",()=>{
  if(answers[current]===undefined)return;
  if(current<questions.length-1){current++;renderQuestion();}
  else show("evaluation");
});
$("finishBtn").addEventListener("click",async()=>{
  $("finishError").textContent="";
  const evaluation=document.querySelector('input[name="evaluation"]:checked')?.value || "Não respondeu";
  $("finishBtn").disabled=true;
  try{
    const result=await api("/api/submit",{method:"POST",body:JSON.stringify({name,answers,evaluation})});
    $("resultName").textContent=`${name}, você acertou`;
    $("scoreNumber").textContent=`${result.score}/${result.total}`;
    show("result");
  }catch(e){$("finishError").textContent=e.message;}
  finally{$("finishBtn").disabled=false;}
});
$("againBtn").addEventListener("click",()=>{ $("participantName").value="";document.querySelectorAll('input[name="evaluation"]').forEach(x=>x.checked=false);show("welcome");});
$("operatorOpen").addEventListener("click",()=>{show("operator");$("loginArea").classList.remove("hidden");$("dashboard").classList.add("hidden");});
$("closeOperator").addEventListener("click",()=>show("welcome"));
$("loginBtn").addEventListener("click",async()=>{
  $("loginError").textContent="";
  try{await api("/api/operator/login",{method:"POST",body:JSON.stringify({password:$("adminPassword").value})});$("loginArea").classList.add("hidden");$("dashboard").classList.remove("hidden");await loadDashboard();}
  catch(e){$("loginError").textContent=e.message;}
});
async function loadDashboard(){
  const data=await api("/api/operator/data");
  $("visitorTotal").textContent=data.uniqueVisitors;
  $("participantTotal").textContent=data.totalParticipants;
  const average=data.results.length?data.results.reduce((s,r)=>s+r.score,0)/data.results.length:0;
  $("averageScore").textContent=`${average.toFixed(1)}/6`;
  const body=$("resultsBody");body.innerHTML="";
  if(!data.results.length){const tr=document.createElement("tr"),td=document.createElement("td");td.colSpan=4;td.className="empty";td.textContent="Nenhuma participação registrada.";tr.append(td);body.append(tr);return;}
  data.results.forEach(r=>{
    const tr=document.createElement("tr");
    [r.name,`${r.score}/${r.total}`,r.evaluation,new Date(r.submittedAt).toLocaleString("pt-BR")].forEach(value=>{const td=document.createElement("td");td.textContent=value;tr.append(td);});
    body.append(tr);
  });
}
$("refreshBtn").addEventListener("click",async()=>{try{await loadDashboard();}catch(e){alert(e.message);}});
$("resetBtn").addEventListener("click",async()=>{
  if(!confirm("Tem certeza? Isso apagará TODOS os resultados e a contagem de acessos."))return;
  try{await api("/api/operator/reset",{method:"POST",body:"{}"});await loadDashboard();alert("Dados resetados.");}catch(e){alert(e.message);}
});
$("logoutBtn").addEventListener("click",async()=>{
  try{await api("/api/operator/logout",{method:"POST",body:"{}"});}catch{}
  $("adminPassword").value="";$("dashboard").classList.add("hidden");$("loginArea").classList.remove("hidden");
});
registerVisit();

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.QUIZ_ADMIN_PASSWORD || "troque-esta-senha";
const DATA_FILE = path.join(__dirname, "data.json");
const PUBLIC_DIR = path.join(__dirname, "public");
const sessions = new Map();

const questions = [
  {
    text: "Como a Inteligência Artificial consegue ajudar a combater o desmatamento ilegal na Amazônia?",
    options: [
      "Prevendo a chuva.",
      "Plantando árvores automaticamente.",
      "Analisando sons da floresta (como motosserras) e imagens de satélite em tempo real."
    ],
    correct: 2
  },
  {
    text: "Qual é um dos principais desafios da implementação de tecnologias avançadas de IA na Amazônia?",
    options: [
      "A infraestrutura de conexão, energia e acesso em áreas isoladas da floresta.",
      "Os animais danificam os robôs.",
      "As árvores bloqueiam o sinal de Wi-Fi comum."
    ],
    correct: 0
  },
  {
    text: "De que forma a IA auxilia os povos tradicionais e cientistas na preservação da biodiversidade?",
    options: [
      "Substituindo o trabalho dos guias locais.",
      "Identificando espécies de plantas e animais por fotos e catalogando a fauna de forma rápida e precisa.",
      "Criando animais virtuais."
    ],
    correct: 1
  },
  {
    text: "Além do desmatamento, qual destas opções representa uma solução real da IA para a floresta?",
    options: [
      "Mudar o clima da região.",
      "Secar os rios para facilitar o acesso.",
      "Monitorar focos de incêndio e prever a rota do fogo antes que ele se espalhe."
    ],
    correct: 2
  },
  {
    text: "Como drones equipados com Inteligência Artificial podem ajudar na proteção da Amazônia?",
    options: [
      "Monitorando áreas de difícil acesso e identificando sinais de desmatamento ou queimadas.",
      "Construindo estradas automaticamente.",
      "Assustando todos os animais para afastá-los da floresta."
    ],
    correct: 0
  },
  {
    text: "Como a Inteligência Artificial pode contribuir para a recuperação de áreas desmatadas?",
    options: [
      "Substituindo todas as árvores por plantas artificiais.",
      "Escolhendo espécies nativas adequadas e ajudando a acompanhar o crescimento das árvores.",
      "Impedindo a chegada de chuva na região."
    ],
    correct: 1
  }
];

function loadData() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch {
    return { visitorIds: [], results: [] };
  }
}
let data = loadData();
function saveData() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}
function parseCookies(req) {
  const out = {};
  (req.headers.cookie || "").split(";").forEach(part => {
    const i = part.indexOf("=");
    if (i > -1) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  });
  return out;
}
function send(res, status, body, type = "application/json; charset=utf-8", extra = {}) {
  res.writeHead(status, { "Content-Type": type, "X-Content-Type-Options": "nosniff", "Cache-Control": "no-store", ...extra });
  res.end(type.startsWith("application/json") ? JSON.stringify(body) : body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", chunk => { raw += chunk; if (raw.length > 100000) reject(new Error("Corpo muito grande")); });
    req.on("end", () => {
      try { resolve(JSON.parse(raw || "{}")); } catch { reject(new Error("JSON inválido")); }
    });
    req.on("error", reject);
  });
}
function isAdmin(req) {
  const token = parseCookies(req).admin_session;
  return !!token && sessions.has(token);
}
function requireAdmin(req, res) {
  if (!isAdmin(req)) { send(res, 401, { error: "Acesso restrito ao operador." }); return false; }
  return true;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  try {
    if (url.pathname === "/api/visit" && req.method === "POST") {
      let cookies = parseCookies(req);
      let visitorId = cookies.visitor_id;
      const headers = {};
      if (!visitorId || !/^[a-f0-9-]{20,50}$/i.test(visitorId)) {
        visitorId = crypto.randomUUID();
        headers["Set-Cookie"] = `visitor_id=${visitorId}; Path=/; Max-Age=31536000; SameSite=Lax; HttpOnly`;
      }
      if (!data.visitorIds.includes(visitorId)) {
        data.visitorIds.push(visitorId);
        saveData();
      }
      return send(res, 200, { ok: true }, undefined, headers);
    }

    if (url.pathname === "/api/questions" && req.method === "GET") {
      return send(res, 200, { questions: questions.map(q => ({ text: q.text, options: q.options })) });
    }

    if (url.pathname === "/api/submit" && req.method === "POST") {
      const body = await readBody(req);
      const name = String(body.name || "").trim().replace(/\s+/g, " ").slice(0, 70);
      if (name.length < 2) return send(res, 400, { error: "Informe seu nome." });
      if (!Array.isArray(body.answers) || body.answers.length !== questions.length) {
        return send(res, 400, { error: "Respostas incompletas." });
      }
      const answers = body.answers.map(v => Number(v));
      if (answers.some(v => !Number.isInteger(v) || v < 0 || v > 2)) {
        return send(res, 400, { error: "Respostas inválidas." });
      }
      const score = answers.reduce((sum, answer, i) => sum + (answer === questions[i].correct ? 1 : 0), 0);
      const evaluation = ["Amei! Nota 10!", "Não gostei.", "Gostei! Nota 9."].includes(body.evaluation) ? body.evaluation : "Não respondeu";
      const record = {
        id: crypto.randomUUID(),
        name,
        score,
        total: questions.length,
        evaluation,
        submittedAt: new Date().toISOString()
      };
      data.results.push(record);
      saveData();
      return send(res, 200, { ok: true, score, total: questions.length });
    }

    if (url.pathname === "/api/operator/login" && req.method === "POST") {
      const body = await readBody(req);
      if (String(body.password || "") !== ADMIN_PASSWORD) return send(res, 401, { error: "Senha incorreta." });
      const token = crypto.randomBytes(32).toString("hex");
      sessions.set(token, Date.now());
      return send(res, 200, { ok: true }, undefined, {
        "Set-Cookie": `admin_session=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=28800`
      });
    }

    if (url.pathname === "/api/operator/logout" && req.method === "POST") {
      const token = parseCookies(req).admin_session;
      if (token) sessions.delete(token);
      return send(res, 200, { ok: true }, undefined, {
        "Set-Cookie": "admin_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"
      });
    }

    if (url.pathname === "/api/operator/data" && req.method === "GET") {
      if (!requireAdmin(req, res)) return;
      return send(res, 200, {
        uniqueVisitors: data.visitorIds.length,
        totalParticipants: data.results.length,
        results: data.results.slice().reverse()
      });
    }

    if (url.pathname === "/api/operator/reset" && req.method === "POST") {
      if (!requireAdmin(req, res)) return;
      data = { visitorIds: [], results: [] };
      saveData();
      return send(res, 200, { ok: true });
    }

    if (url.pathname.startsWith("/api/")) return send(res, 404, { error: "Rota não encontrada." });

    const requested = url.pathname === "/" ? "index.html" : decodeURIComponent(url.pathname.slice(1));
    const file = path.resolve(PUBLIC_DIR, requested);
    if (!file.startsWith(PUBLIC_DIR + path.sep)) return send(res, 403, "Acesso negado.", "text/plain; charset=utf-8");
    fs.readFile(file, (err, content) => {
      if (err) return send(res, 404, "Página não encontrada.", "text/plain; charset=utf-8");
      const ext = path.extname(file);
      const types = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8" };
      send(res, 200, content, types[ext] || "application/octet-stream");
    });
  } catch (err) {
    send(res, 500, { error: "Erro interno. Tente novamente." });
  }
});

server.listen(PORT, () => console.log(`Quiz da Turma 1002 disponível em http://localhost:${PORT}`));
